package chapter_03

class Manager {
    constructor(name: String, salary: Double, age: Int) {}
}