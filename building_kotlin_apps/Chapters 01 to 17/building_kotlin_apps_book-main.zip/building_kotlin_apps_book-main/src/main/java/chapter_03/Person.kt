package chapter_03

class Person constructor(var age: Int, var gender: String, var name: String) {
}