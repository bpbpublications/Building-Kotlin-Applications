package chapter_01.java;


public class Main {
    public static void main(String[] args) {
        String myVar = "This my awesome Java variable";
        System.out.println("Hello World!");
    }
}
