package chapter_01.kotlin

fun main() {
    println("Hello World!")

    val myVar = "This is my Kotlin variable"
}

