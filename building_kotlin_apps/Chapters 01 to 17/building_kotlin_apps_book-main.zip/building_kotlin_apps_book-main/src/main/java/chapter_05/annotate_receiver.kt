package chapter_05

fun @receiver:MyCustomAnnotation(".2f") Double.format() {}