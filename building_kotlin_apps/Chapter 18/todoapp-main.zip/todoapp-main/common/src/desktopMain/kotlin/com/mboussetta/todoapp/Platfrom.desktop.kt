package com.mboussetta.todoapp

actual fun getPlatformName(): String = "Desktop"